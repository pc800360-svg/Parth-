package com.parth.parthconnect

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class PostsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_posts)

        findViewById<TextView>(R.id.tvPosts).text = "Posts / Memories (placeholder)\nUsers can post photos and status here with backend."
    }
}
