package com.parth.parthconnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val tvWelcome = findViewById<TextView>(R.id.tvWelcome)
        val user = intent.getStringExtra("user") ?: "Parth"
        tvWelcome.text = "${'$'}user ❤️ Chehak"

        findViewById<Button>(R.id.btnFriends).setOnClickListener {
            startActivity(Intent(this, FriendsActivity::class.java))
        }
        findViewById<Button>(R.id.btnChat).setOnClickListener {
            startActivity(Intent(this, ChatActivity::class.java))
        }
        findViewById<Button>(R.id.btnCalls).setOnClickListener {
            startActivity(Intent(this, CallsActivity::class.java))
        }
        findViewById<Button>(R.id.btnPosts).setOnClickListener {
            startActivity(Intent(this, PostsActivity::class.java))
        }
    }
}
