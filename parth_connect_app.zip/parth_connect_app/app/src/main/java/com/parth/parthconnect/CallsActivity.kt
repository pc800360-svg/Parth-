package com.parth.parthconnect

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class CallsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calls)

        findViewById<TextView>(R.id.tvCalls).text = "Calls (audio/video) placeholder\nWebRTC integration required for real calls."
    }
}
