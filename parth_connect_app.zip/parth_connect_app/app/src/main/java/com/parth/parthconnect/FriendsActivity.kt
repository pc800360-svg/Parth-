package com.parth.parthconnect

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class FriendsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_friends)

        findViewById<TextView>(R.id.tvFriends).text = "Friends screen (placeholder)\nSend friend requests and accept them here."
    }
}
