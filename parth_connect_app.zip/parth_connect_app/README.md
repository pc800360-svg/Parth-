Parth Connect - Android Studio Project (Starter)
==============================================

This is a ready-to-open Android Studio project tailored for Parth Connect (romantic theme).

What it includes:
- App name: Parth Connect
- Home message: Parth ❤️ Chehak
- Romantic pink theme and simple logo
- Screens: Login, Home, Friends (placeholder), Chat (placeholder), Calls (placeholder), Posts (placeholder)
- Kotlin source files and layouts

Important:
- THIS IS SOURCE CODE (not an APK). To get an installable APK, open the project in Android Studio and Build > Build APK(s).
- If you want, I can provide a GitHub Actions workflow (CI) that will automatically compile an APK when you push the project to your GitHub repo.

How to build on a PC:
1. Download and unzip `parth_connect_app.zip`
2. Open Android Studio and choose "Open an existing project"
3. Let Gradle sync and install any SDK components
4. Build > Build Bundle(s) / APK(s) > Build APK(s)
5. Install the APK on your phone

If you want the GitHub Actions workflow or help building on your phone using Termux, tell me and I'll add it.
